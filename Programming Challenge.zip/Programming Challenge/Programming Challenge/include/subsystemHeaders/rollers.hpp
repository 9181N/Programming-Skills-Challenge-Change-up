#include "main.h"

void index();

void autoIndex();

void intake (int left, int right);

void setRoll(int dep, int low);
