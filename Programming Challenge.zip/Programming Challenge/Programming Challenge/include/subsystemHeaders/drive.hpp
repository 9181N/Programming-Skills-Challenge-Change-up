#include "main.h"
//DRIVER CONTROL
void setDriveMotors();

//AUTONOMOUS FUNCTIONS

double gyroValue();

void encoderGyro(int row);

void setAuto(bool value);

void waitR(int target, int dist);
